from urllib2 import Request, urlopen, URLError, HTTPError

def adminpanel():
	f = open("link.txt","r");
	print ("note: if this framework is done whole framework will exit")
	print good + ("Enter Site Name \n(eg : example.com or www.example.com )") + W
	link = raw_input(BOLD+U+R+"esf"+W+"/admin/panel"+W+BOLD+" >  "+W)
	print ("\n\npreparing to get links... \n")
	print G + "=" *  47 + W
	for i in tqdm.tqdm(range(1000)):
	   time.sleep(0.01)
	print P + ("\n\nGetting Links...\n") + W
	while True:
		sub_link = f.readline()
		if not sub_link:
			break
			print("session stopped not a sublink")
			eagle()
		req_link = "http://"+link+"/"+sub_link
		req = Request(req_link)
		try:
			response = urlopen(req)
		except HTTPError as e:
			continue
		except URLError as e:
			continue
		else:
		   print G + "=" * 47
		   print run + "Link#:\  ",req_link
		   print R + "=" * 47 + W