#!/usr/bin/env python2


Y = '\033[01;33m'
#color Yello
W = '\033[0m'
# white (normal)
R = '\033[31m'
# red
G = '\033[32m'
# green
O = '\033[33m'
# orange
B = '\033[34m'
# blue
P = '\033[35m'
# purple
C = '\033[36m'
# cyan
GR = '\033[37m'
# gray
BOLD = '\033[1m' 
U = '\033[4m'
info = '\033[1;33m[!]\033[1;m'
que = '\033[1;34m[?]\033[1;m'
bad = '\033[1;31m[-]\033[1;m'
good = '\033[1;32m[+]\033[1;m'
run = '\033[1;97m[>]\033[1;m'
realtime = '("%s" % time.strftime("\033[32m[%H:%M:%S]:\033[0m"))'
