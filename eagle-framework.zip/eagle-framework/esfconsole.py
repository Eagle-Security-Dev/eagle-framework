#!/usr/bin/env python2

import os ,time ,sys
import progressbar

from core import tqdm
from core.colors import *
from core import banner
from core import command
from threading import Thread

about = '''
\033[1;32m|\_______             .-==-.            _______/|\033[0;0m
\033[1;32m|        \_______    |    " >   _______/        |\033[0;0m
\033[1;32m\_____           \__/       \__/          ______/\033[0;0m
.\033[1;32m\________                            _________/\033[0;0m.
........\033[1;32m\_______                 ________/\033[0;0m........
..............\033[1;32m\______       ______/\033[0;0m...............
.....................\033[1;32m|     |\033[0;0m......................
...................\033[1;32m / /`  ' \ \033[0;0m....................
...................\033[1;32m| | |`  | |\033[0;0m....................
.................\033[1;32m /__|_||__|__\ \033[0;0m..................
..................................................
[]+============================================+[]
[]\033[1;32m##############################################\033[0;0m[]
--------------------------------------------------

\033[32m EAGLE FRAMEWORK 2.2\033[0m
 ===================

 |(c)copyright 2017|

 Eagle Sec developer created this tool 
 for penetration testing only
 ==========================================
 ##########################################
\033[31m eagle sec developer have no responsibility 
 for any damage created by user\033[0m
 ..........................................
 eagle sec developer [message for user]

 thanks for using my console but dont forget 
 that i made this for penetration testing only. 
 on next update i will enhance my console and i 
 will create reaver and monitoring mode like 
 aircrack-ng and other tool that help 
 kali linux to become a more powerful


 console writer :  V3nd3tt4
'''

usage = '''
usage :  start [-argument]

|args|         |discription|

-su             run as root

-efcterm        run as normal
'''




################
# COMMAND HELP #
################



help = '''
          \033[1;32m|~command list~|\033[0;0m

|restart console|          = usage :  \033[1;32m
restart \033[0;0m

|dos|                      = usage :  \033[1;32m
use ~/eagle-sec/dos/ \033[0;0m

|port scanner|             = usage :  \033[1;32m
use ~/eagle-sec/port_scanner/ \033[0;0m

|udp/tcp flooder|          = usage :  \033[1;32m
use ~/eagle-sec/udp-tcp_flooder/ \033[0;0m

|nmap scanner|             = usage :  \033[1;32m
use ~/eagle-sec/nmap_scanner/ \033[0;0m

|exec|                     = usage :  \033[1;32m
exec                            \033[0;0m

|ftp bruteforce|           = usage :  \033[1;32m
use ~/eagle-sec/ftp-bruteforce/ \033[0;0m

|ssh bruteforce|           = usage :  \033[1;32m
use ~/eagle-sec/ssh-bruteforce/ \033[0;0m

|MySql bruteforce|         = usage :  \033[1;32m
use ~/eagle-sec/MySql-bruteforce/ \033[0;0m

|Web IP retriever|         = usage :  \033[1;32m
use ~/eagle-sec/webIP/ \033[0;0m

|backdoor|                 = usage :  \033[1;32m
start ~/backdoor \033[0;0m

|dos2|                     = usage :  \033[1;32m
start ~/dos2  \033[0;0m

|admin panel|              = usage :  \033[1;32m
start ~/admin-panel  \033[0;0m
'''




#############################
# MAIN RAW INPUT IN CONSOLE #
#############################


def eagle():
   eaglesec = raw_input(BOLD+U+"esf"+W+BOLD+" >  "+W)

   if eaglesec == 'use ~/eagle-sec/nmap_scanner/':
    	 command.nmap()
   	 eagle()
   elif eaglesec == 'help':
      print help
      eagle()
   
   elif eaglesec == 'start ~/dos2':
      print ("\nstarting framework\n") + W
      for i in tqdm.tqdm(range(1000)): 
         time.sleep(0.01)
      command.dos2()
      eagle()
   elif eaglesec == 'use ~/eagle-sec/webIP/':
      print ("\nstarting framework\n") + W
      for i in tqdm.tqdm(range(1000)): 
         time.sleep(0.01)
      command.webIP()
      eagle()
   elif eaglesec == 'use ~/eagle-sec/MySql-bruteforce/':
      print ("\nstarting framework\n") + W
      for i in tqdm.tqdm(range(1000)): 
         time.sleep(0.01)
      command.mysqlbrute()
      eagle()
   elif eaglesec == 'use ~/eagle-sec/ftp-bruteforce/':
      print ("\nstarting framework\n") + W
      for i in tqdm.tqdm(range(1000)): 
         time.sleep(0.01)
      command.ftpbrute()
      eagle()
   elif eaglesec == 'use ~/eagle-sec/ssh-bruteforce/':
      print ("\nstarting framework\n") + W
      for i in tqdm.tqdm(range(1000)): 
         time.sleep(0.01)
      command.sshbrute()
      eagle()
   elif eaglesec == 'start ~/admin-panel':
      print ("\nstarting framework\n") + W
      for i in tqdm.tqdm(range(1000)):
      	 time.sleep(0.01)
      print BOLD + U + ("enter the site [eg. site.com / www.site.com]") + W
      command.adminpanel()
      eagle()
   elif eaglesec == 'use ~/eagle-sec/udp-tcp_flooder/':
      print ("\nstarting framework\n") + W
      for i in tqdm.tqdm(range(1000)): 
         time.sleep(0.01)
      command.udptcpflood()
      eagle()
   elif eaglesec == 'use ~/eagle-sec/gmail-bruteforce/':
      print ("\nstarting framework\n") + W
      for i in tqdm.tqdm(range(1000)): 
         time.sleep(0.01)
      command.gmailbrute()
      eagle()
   elif eaglesec == 'use ~/eagle-sec/dos/':
      print ("\nstarting framework\n") + W
      for i in tqdm.tqdm(range(1000)): 
         time.sleep(0.01)
      command.dos()
      eagle()
   elif eaglesec == 'use ~/eagle-sec/port_scanner/':
      print ("\nstarting framework\n") + W
      for i in tqdm.tqdm(range(1000)): 
         time.sleep(0.01)
      command.portscanner()
      eagle()
   elif eaglesec == 'use ~/eagle-sec/linux_command/':
      print ("\nstarting framework\n") + W
      for i in tqdm.tqdm(range(1000)): 
         time.sleep(0.01)
      command.linux()
      eagle()
   elif eaglesec == 'exit' or eaglesec == 'Exit':
      print ("\nkilling all process\n") + W
      for i in tqdm.tqdm(range(1000)): 
         time.sleep(0.01)
      print R + ("\n"+BOLD+R+"[-]"+W+"esfconsole shutdown\n") + W
      sys.exit()
      
   elif eaglesec == 'clear':
      os.system("clear")
      eagle()
   
   elif eaglesec == 'exec':
      print(BOLD+B+"[+]"+W+" enter your command\n")
      execu = raw_input(BOLD+U+R+"esf"+W+"/exec"+W+BOLD+" >  "+W)
      print ("\n")
      os.system("%s" % (execu))
      eagle()
      
   elif eaglesec == 'restart':
      print G + "=" * 47
      print ("restarting console")
      print G + "#" * 47
      print ("\nplease wait")
      for i in tqdm.tqdm(range(1000)):
         time.sleep(0.01)
      start()

   elif eaglesec == 'banner':
      time.sleep(1.10)
      banner.FirstBanner()
      eagle()
      
   elif eaglesec == 'os-time':
      print ("\ntime check! :  %s\n" % time.strftime("\033[32m[ %H : %M : %S ]\033[0m"))
      eagle()
   
   elif eaglesec == 'about':
      print about
      eagle()

   elif eaglesec == 'reboot':
      print G + "=" * 47
      print ("rebooting console")
      print G + "#" * 47
      print ("please wait")
      time.sleep(10.5)
      main()
   else:
      print(BOLD+R+"[-] unknown command:"+W+" %s\n" % (eaglesec))
      eagle()



###################
# restart feature #
###################


def main2():
   time.sleep(0.90)
   print (R+BOLD+"\n%s" % time.strftime("[%H:%M:%S]")) + (W+BOLD+" session started!")
   time.sleep(2.5)
   banner.FirstBanner()
   eagle()




#################
# START CONSOLE #
#################


def start():
   print("\n")
   bar = progressbar.ProgressBar(
        widgets=['\033[1m\033[34m[:] \033[0mstarting esfconsole  ', progressbar.AnimatedMarker()])
   for i in bar((i for i in range(100))):
        time.sleep(0.20)
   main2()




########
# main #
########

def main():
   start()


if __name__ == '__main__':
  main()
